import hashlib
import mysql.connector
import config


class userr:
    #this is a constructor it doesnt do anything except connecting to the databse 
    #later when you are using this class you create an object and it automaticlly connects to the database 

    def __init__(self):
       
        try:#try statment to check if any error happens 
             self.conn = mysql.connector.connect(
                 #it gets the values from the configuration file 
                host=config.DATABASE_HOST,
                user=config.DATABASE_USER,
                password=config.DATABASE_PASSWORD,
                database=config.DATABASE_NAME,
                port=config.DATABASE_PORT
            )
        except mysql.connector.Error as error:
            print("Error while connecting to MySQL:", error)

        

    def _hashing(self,password):
        #this is the hash function it uses a built in function from the library imported above  
        return hashlib.sha256(password.encode()).hexdigest()
    


    def check_username(self, username):#function to check if username is already taken 
        # Create a cursor object to execute SQL queries
        cursor = self.conn.cursor()
        query = "SELECT * FROM users WHERE username = %s"#query to retrive values about this username 
        values = (username,)
        cursor.execute(query, values)#executes the query with the usernamer 
        # Fetch the result
        result = cursor.fetchone()
        # Close the cursor
        cursor.close()

        if result:#checks if result is false then then there is no username with this value 
            # Username already exists
            return False
        else:
            # Username is available
            return True



    def register(self,username,password):#register function takes username and password 
        try:
            if not self.check_username_availability(username):#checks if username already taken 
                print("Username already taken. Please choose a different username.")
                return
            cursor = self.conn.cursor()

            # Hash the password
            hashed_password = self._hash_password(password)

            # Prepare the SQL query to insert user data
            query = "INSERT INTO users (username, password) VALUES (%s, %s)"
            values = (username, hashed_password)

            # Execute the query
            cursor.execute(query, values)

            # Commit the transaction to save the changes
            self.conn.commit()

            # Close the cursor
            cursor.close()

            print("Registration successful!")
         
        except mysql.connector.Error as error:
            print("Error while executing SQL query:", error)


    def register(self, username, password, first, last, email):
        #i overloaded the registration function to have another version of it that can take all the users info
        try:
            if not self.check_username_availability(username):
                print("Username already taken. Please choose a different username.")
                return
            cursor = self.conn.cursor()

            # Hash the password
            hashed_password = self._hash_password(password)

            # Prepare the SQL query to insert user data
            query = "INSERT INTO users (username, password, first_name, last_name, email) VALUES (%s, %s, %s, %s, %s)"
            values = (username, hashed_password, first, last, email)

            # Execute the query
            cursor.execute(query, values)

            # Commit the transaction to save the changes
            self.conn.commit()

            # Close the cursor
            cursor.close()

            print("Registration successful!")
          
        except mysql.connector.Error as error:
            print("Error while executing SQL query:", error)



def login(self, username, password):
    try:
        # Create a cursor object to execute SQL queries
        cursor = self.conn.cursor()

        # Prepare the SQL query to retrieve the password based on the provided username
        query = "SELECT password FROM users WHERE username = %s"
        values = (username,)

        # Execute the query
        cursor.execute(query, values)

        # Fetch the result
        result = cursor.fetchone()

        # Close the cursor
        cursor.close()

        if result:
            # Password found
            stored_password = result[0]

            # Hash the provided password
            hashed_password = self._hash_password(password)

            if hashed_password == stored_password:#checks if password is the same 
                # Password matches
                print("Login successful!")
               
            else:
                # Password does not match
                print("Invalid password. Please try again.")
        else:
            # User not found
            print("Invalid username. Please try again.")
    except mysql.connector.Error as error:
        print("Error while executing SQL query:", error)



    def get_user_info(self, username):
        try:
            # Create a cursor object to execute SQL queries
            cursor = self.conn.cursor()

            # Prepare the SQL query to retrieve user information based on the provided username
            query = "SELECT username, user_id, first_name, last_name FROM users WHERE username = %s"
            #it will get all the info of the user except the password 
            values = (username,)


            # Execute the query
            cursor.execute(query, values)

            # Fetch the result
            result = cursor.fetchone()

            # Close the cursor
            cursor.close()

            if result:
                # User found
                username, user_id, first_name, last_name = result
                return {
                    "Username": username,
                    "User ID": user_id,
                    "First Name": first_name,
                    "Last Name": last_name
                }
            else:
                # User not found
                return "User not found."
        except mysql.connector.Error as error:
            print("Error while executing SQL query:", error)


def close_connection(self):
        # Close the connection to the database 
        self.conn.close()
         
        