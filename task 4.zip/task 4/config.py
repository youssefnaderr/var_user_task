# config.py

DATABASE_HOST = '127.0.0.1'
DATABASE_USER = 'name'
DATABASE_PASSWORD = 'password'
DATABASE_NAME = 'database task 4'
DATABASE_PORT = 3306

#this is a configration file that has the values to connect with the database 